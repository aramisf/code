#!/usr/bin/perl

use Hello;

hello();

