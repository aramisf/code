#!/usr/bin/perl

package VeryFancyMessage;
use FancyMessage;
@ISA = ('FancyMessage');


1;
